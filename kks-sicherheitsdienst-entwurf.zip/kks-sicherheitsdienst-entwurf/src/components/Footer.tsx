import { company, nav } from "@/lib/content";
import { SHIELD_100 } from "@/lib/shield";

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-deep pb-28 pt-20 text-ivory lg:pb-10">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <p className="display max-w-[14ch] text-[2.8rem] sm:text-[4.4rem] lg:text-[5.4rem]" data-reveal>
          Sicherheit mit <span className="text-brass-light">Zukunft.</span>
        </p>
        <div className="mt-16 grid gap-12 border-y rule-d py-14 md:grid-cols-2 lg:grid-cols-[1.3fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-4">
              <img src="/img/kks-badge-160.webp" alt="" width={60} height={60} className="size-[60px]" loading="lazy" />
              <div>
                <p className="serif text-[1.6rem] leading-none">{company.short}</p>
                <p className="mt-1.5 text-[0.85rem] text-mist">Regional verwurzelt, bundesweit aktiv.</p>
              </div>
            </div>
          </div>
          <div>
            <p className="eyebrow mb-5 text-mist">Anschrift</p>
            <address className="not-italic leading-relaxed text-ivory/85">
              {company.name}
              <br />
              {company.street}
              <br />
              {company.city}
              <span className="mt-3 block text-ivory/55">Vertreten durch: {company.owner}</span>
            </address>
          </div>
          <div>
            <p className="eyebrow mb-5 text-mist">Direktkontakt</p>
            <ul className="text-ivory/85">
              <li>
                <a className="inline-flex min-h-11 items-center gap-2.5 hover:text-brass-light" href={company.emergency.href}>
                  <span className="signal-dot" /> Notfall: <span className="tabular-nums">{company.emergency.label}</span>
                </a>
              </li>
              <li>
                <a className="inline-flex min-h-11 items-center hover:text-brass-light" href={company.phone.href}>
                  Büro:&nbsp;<span className="tabular-nums">{company.phone.label}</span>
                </a>
              </li>
              <li>
                <a className="inline-flex min-h-11 items-center break-all hover:text-brass-light" href={company.email.href}>
                  {company.email.label}
                </a>
              </li>
            </ul>
          </div>
          <div>
            <p className="eyebrow mb-5 text-mist">Navigation</p>
            <ul className="text-ivory/85">
              {nav.map((n) => (
                <li key={n.href}>
                  <a className="inline-flex min-h-10 items-center hover:text-brass-light" href={n.href}>
                    {n.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="flex flex-col gap-4 pt-8 text-[0.85rem] text-ivory/50 lg:flex-row lg:items-center lg:justify-between">
          <p className="max-w-[46rem]">
            Hinweis: Die Inhalte und Angebote dieser Website richten sich ausdrücklich nur an Gewerbetreibende und Unternehmer
            im Sinne des §14 BGB.
          </p>
          <div className="flex shrink-0 flex-wrap items-center gap-x-6">
            <a className="inline-flex min-h-11 items-center hover:text-ivory" href="https://kks-sicherheitsdienst.de/impressum/" target="_blank" rel="noreferrer">
              Impressum
            </a>
            <a className="inline-flex min-h-11 items-center hover:text-ivory" href="https://kks-sicherheitsdienst.de/datenschutz" target="_blank" rel="noreferrer">
              Datenschutzerklärung
            </a>
            <span>© {new Date().getFullYear()} KKS</span>
          </div>
        </div>
      </div>
      <svg viewBox="0 0 100 120" aria-hidden className="pointer-events-none absolute -right-[8vw] -top-[6vw] w-[46vw] max-w-[640px] opacity-[0.05]">
        <path d={SHIELD_100} fill="none" stroke="#f1ebdd" strokeWidth=".5" />
      </svg>
    </footer>
  );
}
