"use client";

import { useEffect, useRef } from "react";
import { company } from "@/lib/content";
import { SHIELD_100 } from "@/lib/shield";
import { clamp, prefersReducedMotion } from "@/lib/motion";
import { shieldPath } from "@/lib/shield";
import { Arrow, Check, Phone } from "./Icons";

/**
 * Leitidee „Das Schild öffnet sich“:
 * Die Seite beginnt hell und ruhig. Im KKS-Wappenschild ist die Nachtstreife zu sehen –
 * beim Scrollen wächst das Schild, bis die Szene den ganzen Bildschirm füllt.
 * Aus einem Zeichen wird Präsenz.
 */
const words = ["Vorausschauend.", "Präsenzstark.", "Einsatzbereit."];
const core = [
  { label: "Objektschutz", sub: "Gebäude, Werke, Anlagen" },
  { label: "Revier- & Streifendienst", sub: "Mobile Kontrollen" },
  { label: "Spezialschutz", sub: "Sensible Einrichtungen" },
];

function geometry() {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (vw >= 1024) return { vw, vh, cx: vw * 0.745, cy: vh * 0.56, s: Math.min(vw * 0.26, vh * 0.46), drop: 0.17 };
  if (vw >= 640) return { vw, vh, cx: vw * 0.5, cy: vh * 0.64, s: Math.min(vw * 0.42, vh * 0.31), drop: 0.3 };
  return { vw, vh, cx: vw * 0.5, cy: vh * 0.63, s: Math.min(vw * 0.48, vh * 0.215), drop: 0.3 };
}

const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export default function Hero() {
  const root = useRef<HTMLElement>(null);
  const clip = useRef<HTMLDivElement>(null);
  const img = useRef<HTMLImageElement>(null);
  const shade = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const one = useRef<HTMLDivElement>(null);
  const two = useRef<HTMLDivElement>(null);
  const hint = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = root.current;
    if (!el || !clip.current) return;
    const reduced = prefersReducedMotion();
    if (reduced) el.style.height = "100svh";

    let g = geometry();
    let raf = 0;
    let mx = 0;
    let my = 0;
    let tx = 0;
    let ty = 0;
    let p = 0;
    let active = true;
    const wordEls = Array.from(two.current?.querySelectorAll<HTMLElement>("[data-word]") ?? []);
    const late = two.current?.querySelector<HTMLElement>("[data-late]");

    const place = () => {
      if (ring.current) {
        const w = g.s * 1.09;
        ring.current.style.width = `${w}px`;
        ring.current.style.left = `${g.cx - w / 2}px`;
        ring.current.style.top = `${g.cy - (w * 1.2) / 2}px`;
      }
    };

    const render = () => {
      const e = reduced ? 0 : easeInOut(clamp(p / 0.52));
      const sMax = Math.hypot(g.vw, g.vh) * 2.7;
      const s = g.s * Math.pow(sMax / g.s, e);
      // Mittelpunkt wandert beim Öffnen leicht zur Bildschirmmitte
      const cx = g.cx + (g.vw / 2 - g.cx) * e;
      const cy = g.cy + (g.vh / 2 - g.cy) * e;
      clip.current!.style.clipPath = e >= 0.999 ? "none" : `path('${shieldPath(cx, cy, s)}')`;
      if (img.current) {
        const k = 1.07 - 0.07 * e;
        const drop = g.vh * g.drop * (1 - e);
        img.current.style.transform = `translate3d(${mx * -14 * (1 - e)}px, ${drop + my * -10 * (1 - e)}px, 0) scale(${k})`;
      }
      if (shade.current) shade.current.style.opacity = `${clamp((p - 0.4) / 0.2)}`;
      if (ring.current) {
        ring.current.style.opacity = `${1 - clamp(p / 0.08)}`;
        ring.current.style.transform = `scale(${1 + p * 3})`;
      }
      if (one.current) {
        const o = 1 - clamp(p / 0.16);
        one.current.style.opacity = `${o}`;
        one.current.style.transform = `translate3d(0, ${-p * 140}px, 0)`;
        one.current.style.pointerEvents = o < 0.3 ? "none" : "";
      }
      if (hint.current) hint.current.style.opacity = `${1 - clamp(p / 0.06)}`;
      wordEls.forEach((w, i) => {
        const o = clamp((p - (0.5 + i * 0.1)) / 0.09);
        w.style.opacity = `${o}`;
        w.style.transform = `translate3d(0, ${(1 - o) * 40}px, 0)`;
      });
      if (late) {
        const o = clamp((p - 0.82) / 0.08);
        late.style.opacity = `${o}`;
        late.style.transform = `translate3d(0, ${(1 - o) * 20}px, 0)`;
        late.style.pointerEvents = o > 0.5 ? "auto" : "none";
      }
    };

    const loop = () => {
      raf = 0;
      mx += (tx - mx) * 0.08;
      my += (ty - my) * 0.08;
      const r = el.getBoundingClientRect();
      p = reduced ? 0 : clamp(-r.top / Math.max(1, r.height - g.vh));
      render();
      if (active && (Math.abs(tx - mx) > 0.002 || Math.abs(ty - my) > 0.002)) raf = requestAnimationFrame(loop);
    };
    const kick = () => {
      if (!raf && active) raf = requestAnimationFrame(loop);
    };
    const onMove = (e: PointerEvent) => {
      tx = e.clientX / g.vw - 0.5;
      ty = e.clientY / g.vh - 0.5;
      kick();
    };
    const onResize = () => {
      g = geometry();
      place();
      kick();
    };
    const io = new IntersectionObserver(([en]) => {
      active = en.isIntersecting;
      kick();
    });
    io.observe(el);

    place();
    render();
    clip.current.style.visibility = "visible";
    window.addEventListener("scroll", kick, { passive: true });
    window.addEventListener("resize", onResize);
    if (window.matchMedia("(hover: hover) and (pointer: fine)").matches && !reduced) window.addEventListener("pointermove", onMove);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", kick);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("pointermove", onMove);
    };
  }, []);

  return (
    <section ref={root} id="top" className="relative h-[200vh] bg-paper">
      <div className="sticky top-0 h-[100svh] min-h-[640px] overflow-hidden">
        {/* goldene Kontur um das Schild */}
        <div ref={ring} className="pointer-events-none absolute will-change-transform" aria-hidden>
          <svg viewBox="-3 -3 106 126" className="w-full overflow-visible">
            <path d={SHIELD_100} fill="none" stroke="#c7a65f" strokeWidth="1.1" />
          </svg>
        </div>

        {/* Szene im Schild */}
        <div ref={clip} className="absolute inset-0 bg-navy will-change-[clip-path]" style={{ visibility: "hidden" }}>
          <picture>
            <source media="(max-width: 767px)" srcSet="/img/hero-nachtstreife-800.webp" />
            <img
              ref={img}
              src="/img/hero-nachtstreife.webp"
              alt="Sicherheitskraft bei einer nächtlichen Kontrollrunde (Symbolbild)"
              width={1600}
              height={1066}
              fetchPriority="high"
              className="absolute inset-0 h-full w-full object-cover object-[82%_42%] will-change-transform sm:object-[88%_42%] lg:object-[76%_50%]"
            />
          </picture>
          <div ref={shade} className="absolute inset-0 bg-[linear-gradient(90deg,rgba(10,9,8,.92)_0%,rgba(10,9,8,.66)_45%,rgba(10,9,8,.2)_100%)] opacity-0 max-lg:bg-[linear-gradient(0deg,rgba(10,9,8,.95)_10%,rgba(10,9,8,.72)_55%,rgba(10,9,8,.4)_100%)]" />

          {/* Phase 2 – auf der geöffneten Szene */}
          <div ref={two} className="absolute inset-0 mx-auto flex max-w-[1600px] flex-col justify-center px-5 pt-28 text-ivory sm:px-8 lg:px-12">
            <p className="display text-[11.2vw] sm:text-[10vw] lg:text-[7.6vw] 2xl:text-[7.8rem]">
              {words.map((w, i) => (
                <span key={w} data-word className={`block opacity-0 will-change-transform ${i === 1 ? "text-brass" : ""}`}>
                  {w}
                </span>
              ))}
            </p>
            <div data-late className="pointer-events-none mt-7 max-w-[34rem] opacity-0 lg:mt-9">
              <p className="text-[1.08rem] text-ivory/80">
                Wir planen, bewachen und reagieren – genau dort, wo Sie Schutz benötigen. Mit klaren Prozessen, geschultem
                Personal und passenden Maßnahmen.
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <a href={company.phone.href} className="btn btn-brass">
                  <Phone className="size-5" /> <span className="tabular-nums">{company.phone.label}</span>
                </a>
                <a href="#kontakt" className="btn btn-line-light">
                  Absicherung anfragen <Arrow className="arrow size-5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Phase 1 – Einstieg */}
        <div ref={one} className="relative z-10 mx-auto flex h-full max-w-[1600px] flex-col px-5 pb-5 pt-[7.6rem] will-change-transform sm:px-8 md:pt-32 lg:justify-center lg:px-12 lg:pb-24 lg:pt-36">
          <p className="flex items-center gap-2.5 text-[0.82rem] font-semibold uppercase tracking-[0.14em] text-brass-deep" style={{ animation: "rise-in 1s var(--ease-out-expo) 1.35s both" }}>
            <span className="h-px w-7 bg-brass-deep" />
            Sicherheitsdienst aus Bergen
          </p>
          <h1 className="display mt-3 text-[15.2vw] sm:text-[11.5vw] lg:mt-5 lg:max-w-[58%] lg:text-[8.2vw] 2xl:text-[8.4rem]">
            <span className="line-mask">
              <span style={{ ["--d" as string]: "1250ms" }}>Sicherheit</span>
            </span>
            <span className="line-mask">
              <span style={{ ["--d" as string]: "1360ms" }}>
                mit <span className="text-brass-deep">Zukunft.</span>
              </span>
            </span>
          </h1>
          <p className="mt-5 hidden max-w-[31rem] text-[1.12rem] text-stone lg:block" style={{ animation: "rise-in 1.1s var(--ease-out-expo) 1.55s both" }}>
            Wir schützen Unternehmen, Objekte und Einrichtungen – regional verwurzelt, bei Bedarf bundesweit im Einsatz.
          </p>

          {/* Leistungen auf einen Blick */}
          <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1 lg:mt-7 lg:gap-x-8" style={{ animation: "rise-in 1.1s var(--ease-out-expo) 1.65s both" }}>
            {core.map((c) => (
              <li key={c.label}>
                <a href="#leistungen" className="flex items-start gap-2 lg:gap-2.5">
                  <Check className="mt-[0.28rem] size-4 shrink-0 text-brass-deep lg:size-[1.15rem]" />
                  <span>
                    <span className="block text-[0.95rem] font-semibold leading-snug lg:text-[1.02rem]">{c.label}</span>
                    <span className="hidden text-[0.86rem] text-stone lg:block">{c.sub}</span>
                  </span>
                </a>
              </li>
            ))}
          </ul>

          <div className="mt-auto grid grid-cols-2 gap-2.5 sm:mx-auto sm:flex sm:gap-3 lg:mx-0 lg:mt-9" style={{ animation: "rise-in 1.1s var(--ease-out-expo) 1.8s both" }}>
            <a href={company.phone.href} className="btn btn-brass max-sm:!px-3">
              <Phone className="size-5" />
              <span className="sm:hidden">Anrufen</span>
              <span className="tabular-nums max-sm:hidden">{company.phone.label}</span>
            </a>
            <a href="#kontakt" className="btn btn-ink max-sm:!px-3">
              <span className="sm:hidden">Anfrage</span>
              <span className="max-sm:hidden">Sicherheitsanfrage stellen</span>
              <Arrow className="arrow size-5 text-brass-light" />
            </a>
          </div>

          <div className="mt-3 flex items-center justify-between gap-4 border-t rule-l pt-2 text-[0.86rem] lg:absolute lg:inset-x-12 lg:bottom-6 lg:mt-0 lg:pt-4" style={{ animation: "fade-in 1.2s ease 2s both" }}>
            <a href={company.emergency.href} className="flex min-h-11 items-center gap-2.5">
              <span className="signal-dot" />
              <span className="text-stone">Notfall</span>
              <span className="font-semibold tabular-nums">{company.emergency.label}</span>
            </a>
            <a href={company.phone.href} className="flex min-h-11 items-center gap-2 sm:hidden">
              <span className="text-stone">Büro</span>
              <span className="font-semibold tabular-nums">{company.phone.label}</span>
            </a>
            <span className="hidden text-stone md:block">Antwort auf Anfragen innerhalb von 24 Stunden</span>
            <div ref={hint} className="hidden items-center gap-3 text-stone lg:flex">
              <span>Weiter scrollen</span>
              <span className="relative h-8 w-px overflow-hidden bg-ink/15">
                <span className="absolute inset-x-0 top-0 h-3 bg-brass-deep" style={{ animation: "hint 1.8s var(--ease-in-out-quint) infinite" }} />
              </span>
            </div>
          </div>
        </div>
        <style>{`@keyframes hint { 0% { transform: translateY(-110%) } 100% { transform: translateY(300%) } }`}</style>
      </div>
    </section>
  );
}
