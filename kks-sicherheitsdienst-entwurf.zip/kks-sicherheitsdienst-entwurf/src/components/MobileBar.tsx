"use client";

import { useEffect, useState } from "react";
import { company } from "@/lib/content";
import { Arrow, Phone } from "./Icons";

/** Mobile Schnellzugriffe: Anrufen · Notfall · Anfrage – immer in Daumenreichweite. */
export default function MobileBar() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const contact = document.getElementById("kontakt");
    let inContact = false;
    const update = () => setShow(window.scrollY > window.innerHeight * 0.5 && !inContact);
    const io = contact
      ? new IntersectionObserver(
          ([e]) => {
            inContact = e.isIntersecting;
            update();
          },
          { rootMargin: "-30% 0px 0px 0px" },
        )
      : null;
    if (contact && io) io.observe(contact);
    window.addEventListener("scroll", update, { passive: true });
    update();
    return () => {
      window.removeEventListener("scroll", update);
      io?.disconnect();
    };
  }, []);

  return (
    <div
      className={`fixed inset-x-3 bottom-3 z-40 transition-[transform,opacity] duration-700 ease-[var(--ease-out-expo)] lg:hidden ${
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-[130%] opacity-0"
      }`}
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="flex items-stretch gap-1.5 rounded-lg border border-white/10 bg-navy/92 p-1.5 text-ivory shadow-[0_18px_50px_-10px_rgba(10,9,8,.7)] backdrop-blur-xl">
        <a href={company.phone.href} className="flex min-h-12 flex-1 items-center justify-center gap-2 rounded-md text-[0.9rem] font-semibold active:bg-white/5" aria-label={`Büro anrufen: ${company.phone.label}`}>
          <Phone className="size-[1.15rem] text-brass-light" /> Anrufen
        </a>
        <a href={company.emergency.href} className="flex min-h-12 flex-1 items-center justify-center gap-2 rounded-md bg-signal/15 text-[0.9rem] font-semibold active:bg-signal/25" aria-label={`Notfall-Telefon: ${company.emergency.label}`}>
          <span className="signal-dot" /> Notfall
        </a>
        <a href="#kontakt" className="flex min-h-12 flex-[1.15] items-center justify-center gap-2 rounded-md bg-brass text-[0.9rem] font-semibold text-ink active:bg-brass-light">
          Anfrage <Arrow className="size-4" />
        </a>
      </div>
    </div>
  );
}
