import type { IconName } from "@/lib/content";

type P = { className?: string };
const base = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  viewBox: "0 0 24 24",
  "aria-hidden": true,
};

const paths: Record<IconName, React.ReactNode> = {
  building: (
    <>
      <path d="M4 21V5.5L12 3l8 2.5V21" />
      <path d="M9 21v-4h6v4M8 8h1M8 11.5h1M15 8h1M15 11.5h1M11.5 8h1M11.5 11.5h1M2.5 21h19" />
    </>
  ),
  route: (
    <>
      <circle cx="6" cy="18" r="2.2" />
      <circle cx="18" cy="6" r="2.2" />
      <path d="M8.2 18H15a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h6.8" strokeDasharray="2.2 2.4" />
    </>
  ),
  shield: (
    <>
      <path d="M12 2.8 4.5 5.6v5.9c0 4.6 3.1 8.2 7.5 9.7 4.4-1.5 7.5-5.1 7.5-9.7V5.6L12 2.8Z" />
      <path d="m8.8 12 2.2 2.2 4.4-4.6" />
    </>
  ),
  door: (
    <>
      <path d="M5 21V4.5A1.5 1.5 0 0 1 6.5 3h11A1.5 1.5 0 0 1 19 4.5V21M3 21h18" />
      <path d="M15 12.5h.01" strokeWidth={2.4} />
    </>
  ),
  badge: (
    <>
      <rect x="4" y="6" width="16" height="14" rx="2" />
      <path d="M9 3h6v3H9zM9.5 15.5c.4-1.4 1.3-2 2.5-2s2.1.6 2.5 2" />
      <circle cx="12" cy="11" r="1.7" />
    </>
  ),
  factory: (
    <>
      <path d="M3 21V11l5 3V11l5 3V11l5 3V5h3v16H3Z" />
      <path d="M7 18h2M12 18h2" />
    </>
  ),
  eye: (
    <>
      <path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),
  home: (
    <>
      <path d="M3.5 10.5 12 3.5l8.5 7V20a1 1 0 0 1-1 1h-15a1 1 0 0 1-1-1v-9.5Z" />
      <path d="M9.5 21v-6h5v6" />
    </>
  ),
  flame: (
    <path d="M12 21c-3.9 0-6.5-2.6-6.5-6.1 0-3.4 2.6-5.3 3.6-8.4.9 1.6 1.4 2.7 1.6 4.1C12.2 8.4 13.5 6 13.3 3c3.4 2.5 5.2 6.6 5.2 10.4 0 4.6-2.6 7.6-6.5 7.6Zm0 0c-1.7 0-2.8-1.2-2.8-2.8 0-1.8 1.6-2.6 2.1-4.2.6.9 2.1 1.9 2.1 3.6 0 .4 0 .7-.1 1" />
  ),
  siren: (
    <>
      <path d="M6 18v-5a6 6 0 0 1 12 0v5M4 21h16M12 3v2M4.2 6.2l1.4 1.4M19.8 6.2l-1.4 1.4" />
      <path d="M10 18v-4.5a2 2 0 0 1 2-2" />
    </>
  ),
  car: (
    <>
      <path d="M3.5 16.5V12l2-5A2 2 0 0 1 7.4 5.7h9.2a2 2 0 0 1 1.9 1.3l2 5v4.5" />
      <path d="M3.5 12h17M2.5 16.5h19v2h-19z" />
      <circle cx="7.5" cy="14.3" r=".6" />
      <circle cx="16.5" cy="14.3" r=".6" />
    </>
  ),
};

export function Icon({ name, className }: P & { name: IconName }) {
  return (
    <svg {...base} className={className}>
      {paths[name]}
    </svg>
  );
}

export function Arrow({ className }: P) {
  return (
    <svg {...base} className={className} strokeWidth={1.8}>
      <path d="M4 12h15M13 6l6 6-6 6" />
    </svg>
  );
}

export function Phone({ className }: P) {
  return (
    <svg {...base} className={className}>
      <path d="M5.2 3.5h3l1.6 4.2-2 1.3a11 11 0 0 0 5.2 5.2l1.3-2 4.2 1.6v3A2 2 0 0 1 16.4 19 14.5 14.5 0 0 1 3 5.6a2 2 0 0 1 2.2-2.1Z" />
    </svg>
  );
}

export function Mail({ className }: P) {
  return (
    <svg {...base} className={className}>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m3.5 6.5 8.5 6.5 8.5-6.5" />
    </svg>
  );
}

export function Pin({ className }: P) {
  return (
    <svg {...base} className={className}>
      <path d="M12 21s-6.5-6.1-6.5-11.2a6.5 6.5 0 0 1 13 0C18.5 14.9 12 21 12 21Z" />
      <circle cx="12" cy="9.8" r="2.3" />
    </svg>
  );
}

export function Check({ className }: P) {
  return (
    <svg {...base} className={className} strokeWidth={2}>
      <path d="m5 12.5 4.2 4.2L19 7" />
    </svg>
  );
}
