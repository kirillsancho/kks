import { company, values } from "@/lib/content";
import { Arrow, Phone } from "./Icons";
import Seal from "./Seal";

/** Warum KKS + Ansprechpartner – ausschließlich belegte Angaben (Website & Impressum). */
export default function About() {
  return (
    <section id="ueber-kks" className="relative z-10 bg-paper py-24 sm:py-28 lg:py-36">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <div className="grid gap-14 lg:grid-cols-[1fr_1.05fr] lg:gap-24">
          <div>
            <p className="eyebrow mb-5 text-brass-deep" data-reveal>
              Warum KKS
            </p>
            <h2 className="display text-[2.9rem] sm:text-[4.2rem] lg:text-[4.9vw] 2xl:text-[5.2rem]">
              <span className="line-mask">
                <span>Verantwortung</span>
              </span>
              <span className="line-mask">
                <span style={{ ["--d" as string]: "100ms" }}>
                  hat einen <span className="text-brass-deep">Namen.</span>
                </span>
              </span>
            </h2>

            <div className="relative mt-12 overflow-hidden rounded-lg bg-chalk p-6 shadow-[0_40px_90px_-55px_rgba(19,17,14,.55)] ring-1 ring-ink/[0.06] sm:p-9" data-reveal>
              <div className="flex flex-col items-start gap-5 sm:flex-row sm:items-center sm:gap-7">
                <Seal size={118} />
                <div>
                  <p className="eyebrow text-stone">Ihr Ansprechpartner</p>
                  <p className="display mt-2 text-[2.2rem] sm:text-[2.7rem]">{company.owner}</p>
                  <p className="mt-1 text-stone">{company.name}</p>
                </div>
              </div>
              <dl className="mt-8 grid gap-x-8 gap-y-5 border-t rule-l pt-7 text-[0.97rem] sm:grid-cols-2">
                {[
                  ["Sitz", `${company.street}, ${company.city}`],
                  ["Handelsregister", company.register],
                  ["Aufsichtsbehörde", company.authority],
                  ["Angebot für", "Gewerbetreibende & Unternehmer"],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt className="eyebrow !text-[0.62rem] text-stone">{k}</dt>
                    <dd className="mt-1 font-medium">{v}</dd>
                  </div>
                ))}
              </dl>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href={company.phone.href} className="btn btn-ink !min-h-12">
                  <Phone className="size-5 text-brass-light" />
                  <span className="tabular-nums">{company.phone.label}</span>
                </a>
                <a href="#kontakt" className="btn btn-line !min-h-12">
                  Nachricht schreiben <Arrow className="arrow size-4" />
                </a>
              </div>
            </div>
          </div>

          <div className="lg:pt-28">
            <p className="serif max-w-[36rem] text-[1.6rem] leading-[1.25] sm:text-[1.95rem]" data-reveal>
              Sicherheit ist Vertrauenssache. Deshalb sprechen Sie bei KKS direkt mit den Menschen, die für Ihren Schutz
              Verantwortung übernehmen.
            </p>
            <ul className="mt-12 border-t rule-l">
              {values.map((v, i) => (
                <li key={v.title} className="group grid grid-cols-[3rem_1fr] gap-x-4 border-b rule-l py-7 sm:grid-cols-[4.5rem_1fr]" data-reveal style={{ ["--d" as string]: `${i * 90}ms` }}>
                  <span className="serif pt-0.5 text-[1.5rem] text-brass-deep transition-transform duration-500 ease-[var(--ease-out-expo)] group-hover:translate-x-1.5">{String(i + 1).padStart(2, "0")}</span>
                  <div>
                    <h3 className="serif text-[1.8rem] leading-tight sm:text-[2rem]">{v.title}</h3>
                    <p className="mt-2 max-w-[32rem] text-stone">{v.text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
