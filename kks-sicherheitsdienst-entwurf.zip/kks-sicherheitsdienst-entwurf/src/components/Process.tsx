"use client";

import { useRef, useState } from "react";
import { steps } from "@/lib/content";
import { clamp, useScrollProgress } from "@/lib/motion";

/** Gepinnte Szene: „Wir planen, bewachen und reagieren“ – ein Wort nach dem anderen tritt hervor. */
export default function Process() {
  const ref = useRef<HTMLElement>(null);
  const bar = useRef<HTMLDivElement>(null);
  const img = useRef<HTMLImageElement>(null);
  const [active, setActive] = useState(0);

  useScrollProgress(
    ref,
    (p) => {
      const i = Math.min(steps.length - 1, Math.floor(clamp(p, 0, 0.999) * steps.length));
      setActive((a) => (a === i ? a : i));
      if (bar.current) bar.current.style.transform = `scaleX(${p})`;
      if (img.current) img.current.style.transform = `scale(${1.2 - p * 0.15})`;
    },
    "sticky",
  );

  return (
    <section ref={ref} id="vorgehen" className="relative h-[300vh] bg-navy text-ivory">
      <div className="sticky top-0 flex h-[100svh] min-h-[600px] flex-col overflow-hidden">
        <picture>
          <source media="(max-width: 767px)" srcSet="/img/leitstelle-800.webp" />
          <img ref={img} src="/img/leitstelle.webp" alt="Sicherheitskräfte beobachten Überwachungsmonitore (Symbolbild)" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-30 will-change-transform" />
        </picture>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_72%_42%,transparent_0%,rgba(18,17,16,.82)_60%,#121110_100%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,#121110_0%,transparent_25%,transparent_72%,#121110_100%)]" />
        <div className="grain absolute inset-0" />

        <div className="relative mx-auto flex w-full max-w-[1600px] flex-1 flex-col justify-center px-5 pt-20 sm:px-8 lg:px-12">
          <p className="eyebrow mb-6 text-brass-light sm:mb-8">So arbeiten wir</p>
          <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_23rem] lg:items-end xl:grid-cols-[minmax(0,1fr)_27rem]">
            <ol className="display text-[18.5vw] leading-[0.95] sm:text-[14.5vw] lg:text-[10vw] 2xl:text-[10rem]">
              {steps.map((s, i) => (
                <li
                  key={s.word}
                  className="flex items-center gap-5 transition-[color,opacity,transform] duration-700 ease-[var(--ease-out-expo)]"
                  style={{
                    color: i === active ? "var(--color-brass-light)" : "var(--color-ivory)",
                    opacity: i === active ? 1 : 0.2,
                    fontStyle: i === active ? "italic" : "normal",
                    transform: i === active ? "translateX(0.12em)" : "none",
                  }}
                  aria-current={i === active ? "step" : undefined}
                >
                  {s.word}
                  <span className="hidden h-px flex-1 origin-left bg-brass-light transition-transform duration-1000 ease-[var(--ease-out-expo)] sm:block" style={{ transform: i === active ? "scaleX(1)" : "scaleX(0)" }} />
                </li>
              ))}
            </ol>
            <div className="relative min-h-[9.5rem] lg:mb-6">
              {steps.map((s, i) => (
                <div
                  key={s.word}
                  className="absolute inset-x-0 top-0 transition-[opacity,transform] duration-700 ease-[var(--ease-out-expo)]"
                  style={{ opacity: i === active ? 1 : 0, transform: i === active ? "none" : `translateY(${i > active ? 18 : -18}px)` }}
                  aria-hidden={i !== active}
                >
                  <p className="eyebrow text-mist">
                    Schritt {i + 1} / {steps.length}
                  </p>
                  <p className="mt-3 text-[1.15rem] leading-relaxed text-ivory/90 sm:text-[1.3rem]">{s.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-[1600px] px-5 pb-24 sm:px-8 lg:px-12 lg:pb-12">
          <div className="h-px w-full bg-white/12">
            <div ref={bar} className="h-full origin-left bg-brass-light" style={{ transform: "scaleX(0)" }} />
          </div>
        </div>
      </div>
    </section>
  );
}
