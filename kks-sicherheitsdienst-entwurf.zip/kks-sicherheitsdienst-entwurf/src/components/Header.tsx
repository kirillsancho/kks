"use client";

import { useEffect, useState } from "react";
import { company, nav } from "@/lib/content";
import { Arrow, Mail, Phone } from "./Icons";

/** Klassische Kopfzeile: Kontaktleiste + Menü, immer sichtbar. */
export default function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50 bg-navy text-ivory shadow-[0_10px_30px_-18px_rgba(0,0,0,.8)]">
        {/* Kontaktleiste */}
        <div className={`hidden overflow-hidden border-b border-white/10 transition-[height] duration-500 ease-[var(--ease-out-expo)] md:block ${scrolled ? "h-0 border-b-0" : "h-9"}`}>
          <div className="mx-auto flex h-9 max-w-[1600px] items-center justify-between px-8 text-[0.8rem] lg:px-12">
            <p className="text-mist max-lg:hidden">Sicherheitsdienst aus Bergen – auch bundesweit verfügbar</p>
            <div className="flex items-center gap-6">
              <a href={company.email.href} className="flex items-center gap-2 text-mist transition-colors hover:text-ivory">
                <Mail className="size-4" /> {company.email.label}
              </a>
              <a href={company.emergency.href} className="flex items-center gap-2 transition-colors hover:text-brass-light">
                <span className="signal-dot" /> <span className="text-mist">Notfall</span> <span className="font-semibold tabular-nums">{company.emergency.label}</span>
              </a>
            </div>
          </div>
        </div>

        <div className="mx-auto flex h-16 max-w-[1600px] items-center justify-between gap-4 px-4 sm:px-8 lg:h-[4.5rem] lg:px-12">
          <a href="#top" className="flex items-center gap-3" aria-label="KKS Sicherheitsdienst – zum Seitenanfang">
            <img src="/img/kks-badge-160.webp" alt="" width={46} height={46} className="size-11 lg:size-[46px]" />
            <span className="leading-none">
              <span className="serif block text-[1.35rem] leading-none tracking-normal">KKS</span>
              <span className="mt-1 block text-[0.6rem] font-semibold uppercase tracking-[0.2em] text-brass">Sicherheitsdienst</span>
            </span>
          </a>

          <nav className="hidden items-center gap-1 md:flex" aria-label="Hauptmenü">
            {nav.map((n) => (
              <a key={n.href} href={n.href} className="group relative whitespace-nowrap px-2.5 py-2 text-[0.88rem] font-medium text-ivory/85 transition-colors hover:text-ivory lg:px-4 lg:text-[0.95rem]">
                {n.label}
                <span className="absolute inset-x-3 bottom-0.5 h-[2px] origin-left scale-x-0 bg-brass transition-transform duration-500 ease-[var(--ease-out-expo)] group-hover:scale-x-100 lg:inset-x-4" />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a href={company.phone.href} className="hidden items-center gap-2.5 px-2 text-[0.95rem] font-semibold tabular-nums transition-colors hover:text-brass-light xl:flex">
              <Phone className="size-5 text-brass" /> {company.phone.label}
            </a>
            <a href="#kontakt" className="btn btn-brass !min-h-11 !px-4 text-[0.88rem] lg:!px-5">
              Anfrage <span className="max-lg:hidden">stellen</span> <Arrow className="arrow size-4" />
            </a>
            <a href={company.phone.href} className="grid size-11 place-items-center rounded-md border border-white/20 text-brass md:hidden" aria-label={`Anrufen: ${company.phone.label}`}>
              <Phone className="size-5" />
            </a>
          </div>
        </div>

        {/* Menüzeile für schmale Bildschirme – immer sichtbar */}
        <nav className="no-scrollbar flex h-10 items-center justify-between gap-4 overflow-x-auto border-t border-white/10 px-4 sm:px-8 md:hidden" aria-label="Menü">
          {nav.map((n) => (
            <a key={n.href} href={n.href} className="flex h-10 shrink-0 items-center whitespace-nowrap text-[0.82rem] font-medium text-ivory/90">
              {n.label}
            </a>
          ))}
        </nav>
      </header>

    </>
  );
}
