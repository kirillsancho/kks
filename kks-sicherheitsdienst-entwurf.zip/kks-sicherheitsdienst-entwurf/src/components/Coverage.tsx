import germany from "@/lib/germany.json";
import { company } from "@/lib/content";
import { Arrow, Pin } from "./Icons";

// gleiche Projektion wie beim Erzeugen der Deutschland-Kontur
const K = Math.cos((51.2 * Math.PI) / 180);
const P = (lon: number, lat: number): [number, number] => [(lon - 5.6) * K * 60, (55.2 - lat) * 60];
const KM = 60 / 111.2; // Pixel pro Kilometer

const [bx, by] = germany.bergen;

// Städte dienen nur der Orientierung auf der Karte
const cities: { n: string; p: [number, number]; dx: number; dy: number; a?: "end" }[] = [
  { n: "Hamburg", p: P(9.99, 53.55), dx: 9, dy: -7 },
  { n: "Hannover", p: P(9.73, 52.37), dx: 9, dy: 13 },
  { n: "Berlin", p: P(13.4, 52.52), dx: -8, dy: 18, a: "end" },
  { n: "Köln", p: P(6.96, 50.94), dx: 10, dy: 4 },
  { n: "Leipzig", p: P(12.37, 51.34), dx: -9, dy: 16, a: "end" },
  { n: "Frankfurt", p: P(8.68, 50.11), dx: 10, dy: 4 },
  { n: "Stuttgart", p: P(9.18, 48.78), dx: 10, dy: 4 },
  { n: "München", p: P(11.58, 48.14), dx: -10, dy: -8, a: "end" },
];

const arc = ([x, y]: [number, number]) => {
  const mx = (bx + x) / 2;
  const my = (by + y) / 2;
  const dx = x - bx;
  const dy = y - by;
  const bend = 0.16;
  return `M${bx} ${by}Q${(mx - dy * bend).toFixed(1)} ${(my + dx * bend).toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)}`;
};

/** Einsatzgebiet: Karte mit Basis Bergen, Entfernungsringen und Verbindungen ins Bundesgebiet. */
export default function Coverage() {
  return (
    <section id="einsatzgebiet" className="relative overflow-hidden bg-navy py-24 text-ivory sm:py-28 lg:py-36">
      <div className="mx-auto grid max-w-[1600px] items-center gap-12 px-5 sm:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-8 lg:px-12">
        <div>
          <p className="mb-4 flex items-center gap-2.5 text-[0.82rem] font-semibold uppercase tracking-[0.14em] text-brass" data-reveal>
            <span className="h-px w-7 bg-brass" /> Einsatzgebiet
          </p>
          <h2 className="display text-[2.9rem] sm:text-[4.2rem] lg:text-[4.9vw] 2xl:text-[5.2rem]" data-reveal>
            Regional verwurzelt. <span className="text-brass">Bundesweit aktiv.</span>
          </h2>
          <p className="mt-6 max-w-[32rem] text-ivory/70" data-reveal>
            Aus Bergen (Niedersachsen) heraus sind wir in der gesamten Region im Einsatz – und bei Bedarf bundesweit. Auch
            größere und überregionale Einsätze planen wir individuell für Sie.
          </p>

          <ol className="mt-9 max-w-[34rem] border-t rule-d">
            {[
              { k: "Basis", v: "Bergen", s: `${company.street} · ${company.city}` },
              { k: "Region", v: "Gesamte Region", s: "Im Einsatz in der gesamten Region rund um Bergen" },
              { k: "Bundesweit", v: "Bei Bedarf deutschlandweit", s: "Überregionale Einsätze nach individueller Planung" },
            ].map((r, i) => (
              <li key={r.k} className="flex gap-5 border-b rule-d py-5" data-reveal style={{ ["--d" as string]: `${i * 100}ms` }}>
                <span className="serif w-8 shrink-0 text-[1.3rem] text-brass">{i + 1}</span>
                <span>
                  <span className="block text-[0.8rem] font-semibold uppercase tracking-[0.13em] text-mist">{r.k}</span>
                  <span className="serif mt-1 block text-[1.6rem] leading-tight">{r.v}</span>
                  <span className="block text-ivory/60">{r.s}</span>
                </span>
              </li>
            ))}
          </ol>

          <div className="mt-8 flex flex-wrap gap-3" data-reveal>
            <a href="#kontakt" className="btn btn-brass">
              Einsatz anfragen <Arrow className="arrow size-5" />
            </a>
            <a href={company.maps} target="_blank" rel="noreferrer" className="btn btn-line-light">
              <Pin className="size-5" /> Standort in Google Maps
            </a>
          </div>
        </div>

        {/* Karte */}
        <div className="map relative mx-auto w-full max-w-[40rem]" data-reveal="fade">
          <div className="pointer-events-none absolute left-[45%] top-[30%] size-[120%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(199,166,95,.16),transparent_60%)]" />
          <svg viewBox={`-34 -14 ${germany.w + 68} ${germany.h + 30}`} className="relative w-full overflow-visible" role="img" aria-label="Deutschlandkarte: Basis Bergen in Niedersachsen, Einsatz bei Bedarf bundesweit">
            <defs>
              <linearGradient id="land" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#2b261d" />
                <stop offset="1" stopColor="#1a1814" />
              </linearGradient>
              <clipPath id="de-clip">
                <path d={germany.d} />
              </clipPath>
              <radialGradient id="glow" cx={bx} cy={by} r="300" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#e2ca92" stopOpacity=".42" />
                <stop offset=".3" stopColor="#c7a65f" stopOpacity=".14" />
                <stop offset="1" stopColor="#c7a65f" stopOpacity="0" />
              </radialGradient>
              <filter id="soft" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="9" />
              </filter>
            </defs>

            {/* Schatten + Landfläche */}
            <path d={germany.d} fill="#000" opacity=".55" transform="translate(0 12)" filter="url(#soft)" />
            <path d={germany.d} fill="url(#land)" />
            <path d={germany.d} fill="url(#glow)" />

            {/* Entfernungsringe + Signal */}
            <g clipPath="url(#de-clip)">
              {[100, 200, 300, 400, 500].map((km) => (
                <circle key={km} cx={bx} cy={by} r={km * KM} fill="none" stroke="#e2ca92" strokeOpacity={km === 100 ? 0.5 : 0.16} strokeWidth=".8" strokeDasharray={km === 100 ? "none" : "2 4"} />
              ))}
              <circle cx={bx} cy={by} r={100 * KM} fill="#c7a65f" opacity=".1" />
              {[0, 1].map((i) => (
                <circle key={i} className="map-wave" cx={bx} cy={by} r="140" fill="none" stroke="#e2ca92" strokeWidth="1.2" style={{ animationDelay: `${i * 2.4}s` }} />
              ))}
            </g>
            <path className="map-outline" d={germany.d} fill="none" stroke="#c7a65f" strokeWidth="1.1" strokeLinejoin="round" pathLength={1} />

            {/* Verbindungen ins Bundesgebiet */}
            {cities.map((c, i) => (
              <path key={c.n} className="map-arc" d={arc(c.p)} fill="none" stroke="#e2ca92" strokeWidth=".9" strokeOpacity=".75" pathLength={1} style={{ transitionDelay: `${1.6 + i * 0.16}s` }} />
            ))}
            {cities.map((c, i) => (
              <g key={c.n} className="map-city" style={{ transitionDelay: `${2.2 + i * 0.16}s` }}>
                <circle cx={c.p[0]} cy={c.p[1]} r="2.6" fill="#121110" stroke="#e2ca92" strokeWidth="1.1" />
                <text x={c.p[0] + c.dx} y={c.p[1] + c.dy} textAnchor={c.a ?? "start"} fill="#a59e90" fontSize="10.5" fontWeight="500">
                  {c.n}
                </text>
              </g>
            ))}

            {/* Ringbeschriftung */}
            <text x={bx + 100 * KM * 0.72} y={by + 100 * KM * 0.72 + 11} fill="#e2ca92" fontSize="8.5" opacity=".8">
              100 km
            </text>
            <text x={bx - 300 * KM * 0.5 - 4} y={by + 300 * KM * 0.87 + 10} fill="#a59e90" fontSize="8.5" textAnchor="end" opacity=".7">
              300 km
            </text>

            {/* Bergen */}
            <circle cx={bx} cy={by} r="13" fill="#c7a65f" opacity=".28" />
            <circle cx={bx} cy={by} r="6" fill="#e2ca92" stroke="#121110" strokeWidth="2" />
            <g>
              <path d={`M${bx - 7} ${by - 7}L${bx - 26} ${by - 30}`} stroke="#f1ebdd" strokeOpacity=".6" />
              <rect x={bx - 122} y={by - 62} width="98" height="38" rx="3" fill="#f6f2e9" />
              <text x={bx - 112} y={by - 44} fill="#8b6c33" fontSize="7.5" fontWeight="700" letterSpacing="1.1">
                BASIS
              </text>
              <text x={bx - 112} y={by - 30.5} fill="#13110e" fontSize="15" style={{ fontFamily: "var(--font-serif)", fontWeight: 600 }}>
                Bergen
              </text>
            </g>
          </svg>
          <p className="relative mt-4 flex flex-wrap items-center justify-center gap-x-6 gap-y-1 text-[0.8rem] text-mist">
            <span className="flex items-center gap-2">
              <span className="size-2.5 rounded-full bg-brass-light" /> Basis Bergen
            </span>
            <span className="flex items-center gap-2">
              <span className="h-px w-5 bg-brass-light" /> Einsätze bei Bedarf bundesweit
            </span>
            <span>Städte dienen der Orientierung</span>
          </p>
          <style>{`
            .map-outline { stroke-dasharray: 1; stroke-dashoffset: 1; transition: stroke-dashoffset 2.6s var(--ease-in-out-quint) .1s; }
            .map-arc { stroke-dasharray: 1; stroke-dashoffset: 1; transition: stroke-dashoffset 1.3s var(--ease-out-expo); }
            .map-city { opacity: 0; transition: opacity .8s ease; }
            .map.is-in .map-outline, .map.is-in .map-arc { stroke-dashoffset: 0; }
            .map.is-in .map-city { opacity: 1; }
            .map-wave { transform-box: fill-box; transform-origin: center; animation: map-wave 4.8s linear infinite; opacity: 0; }
            @keyframes map-wave { 0% { transform: scale(.05); opacity: .8 } 100% { transform: scale(2.4); opacity: 0 } }
            @media (prefers-reduced-motion: reduce) { .map-outline, .map-arc { stroke-dashoffset: 0 } .map-city { opacity: 1 } .map-wave { display: none } }
          `}</style>
        </div>
      </div>
    </section>
  );
}
