import { pillars } from "@/lib/content";
import { Arrow } from "./Icons";

/** Die drei Kernleistungen – sofort verständlich, ohne Scroll-Effekte. */
export default function Pillars() {
  return (
    <section id="leistungen" className="relative bg-paper pt-24 sm:pt-28 lg:pt-36">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr] lg:items-end lg:gap-16">
          <div>
            <p className="mb-4 flex items-center gap-2.5 text-[0.82rem] font-semibold uppercase tracking-[0.14em] text-brass-deep" data-reveal>
              <span className="h-px w-7 bg-brass-deep" /> Unsere Leistungen
            </p>
            <h2 className="display text-[2.7rem] sm:text-[3.8rem] lg:text-[4.6rem]" data-reveal>
              Drei Schwerpunkte. Ein Ziel: <span className="text-brass-deep">Ihre Sicherheit.</span>
            </h2>
          </div>
          <p className="max-w-[32rem] text-stone lg:pb-3" data-reveal style={{ ["--d" as string]: "120ms" }}>
            Schutz von Objekten und Anlagen, mobile Sicherheitsdienste und der sensible Spezialschutz für Einrichtungen – so
            erhalten Sie jederzeit den passenden Schutz: zuverlässig, flexibel und professionell.
          </p>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3 lg:mt-16 lg:gap-7">
          {pillars.map((p, i) => (
            <article key={p.no} className="group flex flex-col overflow-hidden rounded-lg border rule-l bg-chalk transition-[box-shadow,transform] duration-700 ease-[var(--ease-out-expo)] hover:-translate-y-1.5 hover:shadow-[0_34px_70px_-40px_rgba(19,17,14,.55)]" data-reveal style={{ ["--d" as string]: `${i * 110}ms` }}>
              <div className="relative aspect-[16/11] overflow-hidden">
                <picture>
                  <source media="(max-width: 767px)" srcSet={p.imgSm} />
                  <img src={p.img} alt={`${p.title} (Symbolbild)`} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1.4s] ease-[var(--ease-out-expo)] group-hover:scale-[1.06]" />
                </picture>
                <span className="absolute left-0 top-0 bg-ink px-3.5 py-2 text-[0.85rem] font-semibold tabular-nums text-brass">{p.no}</span>
              </div>
              <div className="flex flex-1 flex-col p-6 lg:p-8">
                <h3 lang="de" className="display hyphens-auto text-[1.85rem] leading-[1.05] md:text-[1.5rem] lg:text-[2.2rem]">{p.title}</h3>
                <p className="mt-3 text-stone">{p.text}</p>
                <ul className="mt-5 space-y-1.5 border-t rule-l pt-5 text-[0.95rem]">
                  {p.tags.map((t) => (
                    <li key={t} className="flex items-center gap-2.5">
                      <span className="size-1.5 shrink-0 rotate-45 bg-brass" /> {t}
                    </li>
                  ))}
                </ul>
                <a href="#kontakt" data-service={p.title} className="link mt-auto self-start pt-6 text-brass-deep">
                  Dazu anfragen <Arrow className="arrow size-5" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
