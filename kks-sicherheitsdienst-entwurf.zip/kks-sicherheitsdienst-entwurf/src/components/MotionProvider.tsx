"use client";

import { useEffect } from "react";
import Lenis from "lenis";
import { prefersReducedMotion, scrollToHash } from "@/lib/motion";

/**
 * - Lenis für butterweiches Scrollen auf Desktop (Touch bleibt nativ)
 * - Reveal-Observer für alle [data-reveal] / .line-mask / .clip-reveal
 * - Anker-Links laufen über sanftes Scrollen
 */
export default function MotionProvider() {
  useEffect(() => {
    const reduced = prefersReducedMotion();
    let lenis: Lenis | null = null;
    let raf = 0;

    if (!reduced) {
      lenis = new Lenis({ duration: 1.15, easing: (t) => 1 - Math.pow(1 - t, 4), smoothWheel: true });
      (window as unknown as { __lenis?: Lenis }).__lenis = lenis;
      const loop = (time: number) => {
        lenis?.raf(time);
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
    }

    // Reveal
    const selector = "[data-reveal], .line-mask, .img-reveal, [data-reveal-group]";
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add("is-in");
            io.unobserve(e.target);
          }
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
    );
    const observeAll = () => document.querySelectorAll(selector).forEach((el) => !el.classList.contains("is-in") && io.observe(el));
    observeAll();
    const mo = new MutationObserver(observeAll);
    mo.observe(document.body, { childList: true, subtree: true });

    // Anker-Links
    const onClick = (ev: MouseEvent) => {
      const a = (ev.target as HTMLElement).closest("a[href^='#']") as HTMLAnchorElement | null;
      if (!a) return;
      const hash = a.getAttribute("href");
      if (!hash || hash.length < 2) return;
      ev.preventDefault();
      window.dispatchEvent(new CustomEvent("kks:navigate"));
      scrollToHash(hash);
    };
    document.addEventListener("click", onClick);

    return () => {
      cancelAnimationFrame(raf);
      lenis?.destroy();
      io.disconnect();
      mo.disconnect();
      document.removeEventListener("click", onClick);
    };
  }, []);

  return null;
}
