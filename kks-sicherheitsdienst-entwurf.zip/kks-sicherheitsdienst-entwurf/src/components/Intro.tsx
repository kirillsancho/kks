"use client";

import { useEffect, useState } from "react";
import { prefersReducedMotion } from "@/lib/motion";
import { SHIELD_100 } from "@/lib/shield";

/** Kurzes Marken-Intro: das Schild zeichnet sich, dann hebt sich der Vorhang. */
export default function Intro() {
  const [phase, setPhase] = useState<"in" | "out" | "done">("in");

  useEffect(() => {
    if (prefersReducedMotion()) {
      setPhase("done");
      window.dispatchEvent(new CustomEvent("kks:intro-done"));
      return;
    }
    const t1 = setTimeout(() => {
      setPhase("out");
      window.dispatchEvent(new CustomEvent("kks:intro-done"));
    }, 1250);
    const t2 = setTimeout(() => setPhase("done"), 2250);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (phase === "done") return null;

  return (
    <div
      aria-hidden
      className="fixed inset-0 z-[100] grid place-items-center bg-navy text-ivory transition-[clip-path] duration-[950ms] ease-[var(--ease-in-out-quint)]"
      style={{ clipPath: phase === "out" ? "inset(0 0 100% 0)" : "inset(0 0 0 0)" }}
    >
      <div className="relative grid place-items-center">
        <svg viewBox="-4 -4 108 128" className="w-[104px] overflow-visible" fill="none">
          <path d={SHIELD_100} stroke="#e2ca92" strokeWidth="1.4" pathLength={1} strokeDasharray="1" strokeDashoffset="1" style={{ animation: "intro-draw 1.1s var(--ease-in-out-quint) both" }} />
        </svg>
        <span className="serif absolute text-[2rem]" style={{ animation: "fade-in .7s ease .35s both" }}>
          KKS
        </span>
      </div>
      <style>{`@keyframes intro-draw { to { stroke-dashoffset: 0 } }`}</style>
    </div>
  );
}
