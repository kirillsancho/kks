/** KKS-Siegel mit rotierendem Schriftring */
export default function Seal({ size = 150, color = "#8a6b32" }: { size?: number; color?: string }) {
  return (
    <div className="relative grid shrink-0 place-items-center" style={{ width: size, height: size }}>
      <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full" aria-hidden>
        <defs>
          <path id="seal-ring" d="M100,100 m-88,0 a88,88 0 1,1 176,0 a88,88 0 1,1 -176,0" />
        </defs>
        <text fill={color} fontSize="10.5" style={{ textTransform: "uppercase", fontStretch: "122%", fontWeight: 600 }}>
          <textPath href="#seal-ring" textLength="544" lengthAdjust="spacing">
            Sicherheit mit Zukunft · KKS Sicherheitsdienst ·
          </textPath>
        </text>
      </svg>
      <img src="/img/kks-badge-160.webp" alt="Siegel KKS Sicherheitsdienst" width={160} height={159} loading="lazy" className="relative w-[62%]" />
    </div>
  );
}
