"use client";

import { useState } from "react";
import { categories, services, type CategoryId } from "@/lib/content";
import { Arrow, Icon } from "./Icons";

/** Gesamtes Portfolio als Bedarfs-Finder: erst Situation wählen, dann passende Leistungen sehen. */
export default function Portfolio() {
  const [cat, setCat] = useState<CategoryId>("alle");
  const [open, setOpen] = useState<string | null>("objektschutz");
  const visible = services.filter((s) => cat === "alle" || s.cats.includes(cat));

  const choose = (id: CategoryId) => {
    setCat(id);
    const list = services.filter((s) => id === "alle" || s.cats.includes(id));
    setOpen(list[0]?.id ?? null);
  };

  return (
    <section id="portfolio" className="relative bg-paper py-20 sm:py-24 lg:py-32">
      <div className="mx-auto grid max-w-[1600px] gap-12 px-5 sm:px-8 lg:grid-cols-[23rem_1fr] lg:gap-20 lg:px-12 xl:grid-cols-[27rem_1fr]">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <p className="mb-4 flex items-center gap-2.5 text-[0.82rem] font-semibold uppercase tracking-[0.14em] text-brass-deep" data-reveal>
            <span className="h-px w-7 bg-brass-deep" /> Alle Leistungen
          </p>
          <h2 className="display text-[2.6rem] sm:text-[3.3rem] lg:text-[3.5rem]" data-reveal>
            Was möchten Sie <span className="text-brass-deep">schützen?</span>
          </h2>
          <p className="mt-5 text-stone" data-reveal>
            Wählen Sie Ihre Situation – wir zeigen die passenden Leistungen. Jedes Einsatzgebiet wird individuell geplant und
            exakt auf Ihre Anforderungen abgestimmt.
          </p>

          <div role="tablist" aria-label="Leistungen filtern" className="no-scrollbar -mx-5 mt-8 flex gap-2 overflow-x-auto px-5 pb-2 sm:-mx-8 sm:px-8 lg:mx-0 lg:flex-wrap lg:overflow-visible lg:px-0" data-reveal>
            {categories.map((c) => {
              const active = c.id === cat;
              const count = c.id === "alle" ? services.length : services.filter((s) => s.cats.includes(c.id)).length;
              return (
                <button
                  key={c.id}
                  role="tab"
                  type="button"
                  aria-selected={active}
                  onClick={() => choose(c.id)}
                  className={`flex min-h-11 shrink-0 items-center gap-2 rounded-md border px-4 text-[0.9rem] transition-[background-color,color,border-color,transform] duration-300 active:scale-[0.97] ${
                    active ? "border-ink bg-ink text-ivory" : "rule-l bg-chalk/60 hover:border-ink/50"
                  }`}
                >
                  {c.label}
                  <span className={`text-[0.72rem] tabular-nums ${active ? "text-brass-light" : "text-stone"}`}>{count}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="border-t rule-l" aria-live="polite">
          {services.map((s) => {
            const shown = visible.includes(s);
            const isOpen = shown && open === s.id;
            const n = visible.indexOf(s) + 1;
            return (
              <div key={s.id} className="grid transition-[grid-template-rows,opacity] duration-700 ease-[var(--ease-out-expo)]" style={{ gridTemplateRows: shown ? "1fr" : "0fr", opacity: shown ? 1 : 0 }} aria-hidden={!shown}>
                <div className="min-h-0 overflow-hidden">
                  <div className={`group border-b rule-l transition-colors duration-500 ${isOpen ? "bg-chalk" : ""}`}>
                    <button type="button" tabIndex={shown ? 0 : -1} aria-expanded={isOpen} onClick={() => setOpen(isOpen ? null : s.id)} className="flex w-full items-center gap-4 px-1 py-5 text-left sm:gap-6 sm:px-5 sm:py-6">
                      <span className="w-7 shrink-0 text-[0.8rem] tabular-nums text-stone">{String(n).padStart(2, "0")}</span>
                      <span className={`grid size-11 shrink-0 place-items-center rounded-full border transition-colors duration-500 ${isOpen ? "border-ink bg-ink text-brass-light" : "rule-l text-brass-deep group-hover:border-ink/50"}`}>
                        <Icon name={s.icon} className="size-5" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className={`serif block text-[1.35rem] leading-[1.15] transition-transform duration-500 ease-[var(--ease-out-expo)] sm:text-[1.75rem] ${isOpen ? "" : "group-hover:translate-x-1.5"}`}>{s.title}</span>
                        {s.core && <span className="eyebrow mt-1.5 block !text-[0.62rem] text-brass-deep">Kernkompetenz</span>}
                      </span>
                      <span className="relative size-5 shrink-0" aria-hidden>
                        <span className="absolute left-0 top-1/2 h-px w-5 bg-ink" />
                        <span className={`absolute left-0 top-1/2 h-px w-5 bg-ink transition-transform duration-500 ease-[var(--ease-out-expo)] ${isOpen ? "rotate-0" : "rotate-90"}`} />
                      </span>
                    </button>
                    <div className="grid transition-[grid-template-rows] duration-700 ease-[var(--ease-out-expo)]" style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}>
                      <div className="min-h-0 overflow-hidden">
                        <div className="flex flex-col gap-5 pb-7 pl-1 pr-1 sm:pl-[7.25rem] sm:pr-10 md:flex-row md:items-end md:justify-between">
                          <p className="max-w-[36rem] text-stone">{s.text}</p>
                          <a href="#kontakt" data-service={s.title} tabIndex={isOpen ? 0 : -1} className="btn btn-line !min-h-12 shrink-0 self-start text-[0.88rem] md:self-auto">
                            Leistung anfragen <Arrow className="arrow size-4" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
