"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { company, services, type IconName } from "@/lib/content";
import { scrollToHash } from "@/lib/motion";
import { Arrow, Check, Icon, Mail, Phone, Pin } from "./Icons";

const topics: { label: string; icon: IconName | null }[] = [
  ...services.map((s) => ({ label: s.short, icon: s.icon as IconName })),
  { label: "Noch unklar – bitte beraten", icon: null },
];
const timings = ["Ab sofort", "Geplanter Termin", "Dauerhaft", "Noch offen"];
const stepNames = ["Bedarf", "Einsatz", "Kontakt"];

type Status = "idle" | "sending" | "sent";

function LineField({
  label,
  name,
  type = "text",
  required,
  autoComplete,
  inputMode,
  error,
  hint,
  value,
  onChange,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  autoComplete?: string;
  inputMode?: "tel" | "email" | "text";
  error?: boolean;
  hint?: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="group block">
      <span className="flex items-baseline justify-between text-[0.86rem] font-semibold">
        <span>
          {label}
          {required && <span className="text-brass-deep"> *</span>}
        </span>
        {hint && <span className="font-normal text-stone">{hint}</span>}
      </span>
      <span className="relative mt-1 block">
        <input
          name={name}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
          autoComplete={autoComplete}
          inputMode={inputMode}
          aria-invalid={error || undefined}
          className={`peer h-[3.25rem] w-full border-b bg-transparent text-[1.1rem] text-ink outline-none transition-colors duration-300 placeholder:text-stone/50 ${error ? "border-signal" : "border-ink/25"}`}
        />
        <span className="pointer-events-none absolute inset-x-0 bottom-0 h-[2px] origin-left scale-x-0 bg-brass-deep transition-transform duration-500 ease-[var(--ease-out-expo)] peer-focus:scale-x-100" />
      </span>
    </label>
  );
}

export default function Contact() {
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<string[]>([]);
  const [timing, setTiming] = useState<string | null>(null);
  const [v, setV] = useState({ place: "", message: "", name: "", company: "", phone: "", email: "" });
  const [errors, setErrors] = useState<string[]>([]);
  const [status, setStatus] = useState<Status>("idle");
  const card = useRef<HTMLDivElement>(null);
  const set = (k: keyof typeof v) => (val: string) => setV((o) => ({ ...o, [k]: val }));

  // „Dazu anfragen“-Links aus den Leistungsbereichen wählen das Thema vor
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      const a = (e.target as HTMLElement).closest<HTMLElement>("[data-service]");
      if (!a) return;
      const match = services.find((s) => s.title === a.dataset.service);
      if (match) {
        setPicked((p) => (p.includes(match.short) ? p : [...p, match.short]));
        setStep(0);
        setStatus("idle");
      }
    };
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  const go = (n: number) => {
    setStep(n);
    const top = card.current?.getBoundingClientRect().top ?? 0;
    if (top < 60) scrollToHash("#anfrage");
  };
  const toggle = (t: string) => setPicked((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]));

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (step < 2) return go(step + 1);
    const missing = (["name", "phone", "email"] as const).filter((k) => !v[k].trim()) as string[];
    if (v.email && !/^\S+@\S+\.\S+$/.test(v.email)) missing.push("email");
    setErrors(missing);
    if (missing.length) return;
    // ENTWURF: kein Backend – hier später den Versand anbinden.
    setStatus("sending");
    setTimeout(() => setStatus("sent"), 1100);
  };

  const reset = () => {
    setStatus("idle");
    setStep(0);
    setPicked([]);
    setTiming(null);
    setV({ place: "", message: "", name: "", company: "", phone: "", email: "" });
  };

  return (
    <section id="kontakt" className="relative bg-bone py-24 sm:py-28 lg:py-36">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr] lg:items-end lg:gap-16">
          <div>
            <p className="mb-4 flex items-center gap-2.5 text-[0.82rem] font-semibold uppercase tracking-[0.14em] text-brass-deep" data-reveal>
              <span className="h-px w-7 bg-brass-deep" /> Kontakt
            </p>
            <h2 className="display text-[2.9rem] sm:text-[4.2rem] lg:text-[5rem]" data-reveal>
              Sprechen wir über <span className="text-brass-deep">Ihre Sicherheit.</span>
            </h2>
          </div>
          <p className="max-w-[30rem] text-stone lg:pb-3" data-reveal style={{ ["--d" as string]: "120ms" }}>
            In drei kurzen Schritten zur Anfrage – oder Sie rufen direkt an. Wir antworten garantiert innerhalb von 24
            Stunden.
          </p>
        </div>

        <div id="anfrage" ref={card} className="mt-12 grid overflow-hidden rounded-lg bg-chalk shadow-[0_50px_110px_-60px_rgba(19,17,14,.6)] ring-1 ring-ink/[0.07] lg:mt-16 lg:grid-cols-[1.45fr_1fr]" data-reveal>
          {/* Formular */}
          <div className="relative p-5 sm:p-9 lg:p-12">
            {/* Erfolg */}
            <div className={`absolute inset-0 z-10 flex flex-col items-center justify-center bg-chalk p-8 text-center transition-[opacity,visibility] duration-700 ${status === "sent" ? "visible opacity-100" : "invisible opacity-0"}`} role="status" aria-hidden={status !== "sent"}>
              <div className="grid size-20 place-items-center rounded-full bg-ink text-brass transition-transform duration-1000 ease-[var(--ease-out-expo)]" style={{ transform: status === "sent" ? "scale(1)" : "scale(.4)" }}>
                <Check className="size-9" />
              </div>
              <h3 className="display mt-7 text-[2.6rem]">Anfrage erfasst.</h3>
              <p className="mt-3 max-w-[25rem] text-stone">
                Vielen Dank{v.name ? `, ${v.name.split(" ")[0]}` : ""}. Wir melden uns innerhalb von 24 Stunden. In dringenden Fällen erreichen Sie uns unter{" "}
                <a href={company.emergency.href} className="font-semibold text-ink underline decoration-brass-deep underline-offset-4">
                  {company.emergency.label}
                </a>
                .
              </p>
              <p className="mt-6 rounded-md bg-ink/[0.06] px-4 py-2 text-[0.8rem] text-stone">Entwurf – der Versand wird erst zum Livegang angebunden.</p>
              <button type="button" onClick={reset} tabIndex={status === "sent" ? 0 : -1} className="mt-5 min-h-11 font-semibold underline decoration-brass-deep underline-offset-4">
                Weitere Anfrage stellen
              </button>
            </div>

            <form onSubmit={submit} noValidate className={status === "sent" ? "invisible" : ""}>
              {/* Fortschritt */}
              <ol className="grid grid-cols-3 gap-2 sm:gap-3">
                {stepNames.map((n, i) => (
                  <li key={n}>
                    <button type="button" onClick={() => i < step && go(i)} disabled={i > step} className="block w-full text-left disabled:cursor-default" aria-current={i === step ? "step" : undefined}>
                      <span className="block h-[3px] overflow-hidden bg-ink/10">
                        <span className="block h-full origin-left bg-brass-deep transition-transform duration-700 ease-[var(--ease-out-expo)]" style={{ transform: `scaleX(${i <= step ? 1 : 0})` }} />
                      </span>
                      <span className={`mt-2.5 flex items-center gap-2 text-[0.84rem] font-semibold transition-colors ${i <= step ? "text-ink" : "text-stone/70"}`}>
                        <span className={`grid size-5 place-items-center rounded-full text-[0.7rem] ${i < step ? "bg-brass-deep text-chalk" : i === step ? "bg-ink text-chalk" : "bg-ink/10"}`}>{i < step ? <Check className="size-3" /> : i + 1}</span>
                        {n}
                      </span>
                    </button>
                  </li>
                ))}
              </ol>

              <div className="mt-9 min-h-[25rem] sm:min-h-[23rem]">
                {step === 0 && (
                  <div key="s0" style={{ animation: "rise-in .7s var(--ease-out-expo) both" }}>
                    <h3 className="display text-[2rem] sm:text-[2.4rem]">Was möchten Sie absichern?</h3>
                    <p className="mt-1.5 text-stone">Mehrfachauswahl möglich – oder einfach weiter.</p>
                    <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-3">
                      {topics.map((t) => {
                        const on = picked.includes(t.label);
                        return (
                          <button
                            key={t.label}
                            type="button"
                            aria-pressed={on}
                            onClick={() => toggle(t.label)}
                            className={`relative flex min-h-[4.25rem] gap-2 rounded-md border px-3 py-3 text-left text-[0.86rem] font-medium leading-tight hyphens-auto max-sm:flex-col max-sm:items-start sm:items-center sm:gap-3 sm:px-3.5 sm:text-[0.92rem] transition-[background-color,color,border-color,transform] duration-300 active:scale-[0.98] ${
                              on ? "border-ink bg-ink text-ivory" : "border-ink/12 bg-white hover:border-brass-deep"
                            } ${t.icon ? "" : "col-span-2 sm:col-span-1"}`}
                          >
                            {t.icon ? <Icon name={t.icon} className={`size-5 shrink-0 ${on ? "text-brass" : "text-brass-deep"}`} /> : <span className={`serif shrink-0 text-[1.3rem] leading-none ${on ? "text-brass" : "text-brass-deep"}`}>?</span>}
                            <span lang="de">{t.label}</span>
                            {on && <Check className="absolute right-2 top-2 size-3.5 text-brass" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {step === 1 && (
                  <div key="s1" style={{ animation: "rise-in .7s var(--ease-out-expo) both" }}>
                    <h3 className="display text-[2rem] sm:text-[2.4rem]">Wo und wann wird Schutz benötigt?</h3>
                    <p className="mt-1.5 text-stone">Grobe Angaben genügen – Details klären wir persönlich.</p>
                    <div className="mt-7 grid gap-7">
                      <LineField label="Einsatzort" name="place" hint="optional" autoComplete="address-level2" value={v.place} onChange={set("place")} />
                      <div>
                        <p className="text-[0.86rem] font-semibold">Zeitraum</p>
                        <div className="mt-2.5 grid grid-cols-2 gap-2 sm:grid-cols-4">
                          {timings.map((t) => {
                            const on = timing === t;
                            return (
                              <button key={t} type="button" aria-pressed={on} onClick={() => setTiming(on ? null : t)} className={`min-h-12 rounded-md border px-3 text-[0.92rem] font-medium transition-[background-color,color,border-color] duration-300 ${on ? "border-ink bg-ink text-ivory" : "border-ink/12 bg-white hover:border-brass-deep"}`}>
                                {t}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                      <label className="block">
                        <span className="flex items-baseline justify-between text-[0.86rem] font-semibold">
                          Ihre Nachricht <span className="font-normal text-stone">optional</span>
                        </span>
                        <textarea name="message" rows={3} value={v.message} onChange={(e) => set("message")(e.target.value)} placeholder="Objekt, Besonderheiten, Fragen …" className="mt-2 w-full resize-y rounded-md border border-ink/15 bg-white px-4 py-3 text-[1.05rem] outline-none transition-[border-color,box-shadow] duration-300 placeholder:text-stone/50 focus:border-brass-deep focus:shadow-[0_0_0_3px_rgba(199,166,95,.3)]" />
                      </label>
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div key="s2" style={{ animation: "rise-in .7s var(--ease-out-expo) both" }}>
                    <h3 className="display text-[2rem] sm:text-[2.4rem]">Wie erreichen wir Sie?</h3>
                    <p className="mt-1.5 text-stone">Wir melden uns persönlich – innerhalb von 24 Stunden.</p>
                    <div className="mt-7 grid gap-x-8 gap-y-6 sm:grid-cols-2">
                      <LineField label="Name" name="name" required autoComplete="name" error={errors.includes("name")} value={v.name} onChange={set("name")} />
                      <LineField label="Unternehmen" name="company" autoComplete="organization" value={v.company} onChange={set("company")} />
                      <LineField label="Telefon" name="phone" type="tel" inputMode="tel" required autoComplete="tel" error={errors.includes("phone")} value={v.phone} onChange={set("phone")} />
                      <LineField label="E-Mail" name="email" type="email" inputMode="email" required autoComplete="email" error={errors.includes("email")} value={v.email} onChange={set("email")} />
                    </div>
                    {errors.length > 0 && (
                      <p className="mt-4 text-[0.9rem] font-medium text-[#b23a26]" role="alert">
                        Bitte prüfen Sie die markierten Felder – Name, Telefon und eine gültige E-Mail-Adresse werden benötigt.
                      </p>
                    )}
                    {(picked.length > 0 || timing || v.place) && (
                      <p className="mt-7 border-l-2 border-brass pl-4 text-[0.92rem] text-stone">
                        <span className="font-semibold text-ink">Ihre Anfrage:</span> {[picked.join(", "), v.place, timing].filter(Boolean).join(" · ")}
                      </p>
                    )}
                  </div>
                )}
              </div>

              <div className="mt-8 flex items-center justify-between gap-4 border-t rule-l pt-6">
                {step > 0 ? (
                  <button type="button" onClick={() => go(step - 1)} className="min-h-12 px-1 font-semibold text-stone transition-colors hover:text-ink">
                    ← Zurück
                  </button>
                ) : (
                  <span className="text-[0.86rem] text-stone max-sm:hidden">Dauert weniger als eine Minute</span>
                )}
                <button type="submit" disabled={status === "sending"} className="btn btn-ink ml-auto disabled:opacity-80">
                  {status === "sending" ? (
                    <>
                      <span className="size-4 animate-spin rounded-full border-2 border-ivory/30 border-t-ivory" /> Wird gesendet …
                    </>
                  ) : (
                    <>
                      {step < 2 ? "Weiter" : "Anfrage absenden"} <Arrow className="arrow size-5 text-brass" />
                    </>
                  )}
                </button>
              </div>
              {step === 2 && <p className="mt-4 text-[0.8rem] leading-relaxed text-stone">Ihre Angaben verwenden wir ausschließlich zur Bearbeitung Ihrer Anfrage. Angebot nur für Gewerbetreibende und Unternehmer.</p>}
            </form>
          </div>

          {/* Direktkontakt */}
          <aside className="relative flex flex-col bg-navy p-6 text-ivory sm:p-9 lg:p-12">
            <div className="pointer-events-none absolute -right-24 -top-24 size-72 rounded-full bg-[radial-gradient(circle,rgba(199,166,95,.2),transparent_65%)]" />
            <p className="text-[0.82rem] font-semibold uppercase tracking-[0.14em] text-brass">Lieber direkt sprechen?</p>
            <a href={company.phone.href} className="group mt-4 block">
              <span className="display block text-[2.5rem] tabular-nums transition-colors group-hover:text-brass-light sm:text-[3rem]">{company.phone.label}</span>
              <span className="mt-1 flex items-center gap-2 text-mist">
                <Phone className="size-4 text-brass" /> Büro Bergen – Ihr Ansprechpartner: {company.owner}
              </span>
            </a>

            <a href={company.emergency.href} className="mt-8 flex items-center justify-between gap-4 rounded-md border border-signal/40 bg-signal/[0.08] p-4 transition-colors hover:border-signal/80">
              <span className="flex items-center gap-3.5">
                <span className="grid size-10 shrink-0 place-items-center rounded-full border border-signal/50">
                  <span className="signal-dot" />
                </span>
                <span>
                  <span className="block text-[0.8rem] font-semibold uppercase tracking-[0.12em] text-mist">Notfall-Telefon</span>
                  <span className="serif block text-[1.6rem] leading-tight tabular-nums">{company.emergency.label}</span>
                </span>
              </span>
              <Arrow className="size-5 shrink-0 text-ivory/60" />
            </a>

            <ul className="mt-8 space-y-1 border-t rule-d pt-6 text-[0.97rem]">
              <li>
                <a href={company.email.href} className="flex min-h-11 items-center gap-3 break-all transition-colors hover:text-brass-light">
                  <Mail className="size-5 shrink-0 text-brass" /> {company.email.label}
                </a>
              </li>
              <li>
                <a href={company.maps} target="_blank" rel="noreferrer" className="flex min-h-11 items-center gap-3 transition-colors hover:text-brass-light">
                  <Pin className="size-5 shrink-0 text-brass" /> {company.street}, {company.city}
                </a>
              </li>
            </ul>

            <ul className="mt-auto space-y-2.5 pt-10 text-[0.92rem] text-ivory/80">
              {["Antwort garantiert innerhalb von 24 Stunden", "Individuell geplante Sicherheitslösung", "Direkte Kommunikation ohne Umwege"].map((t) => (
                <li key={t} className="flex items-start gap-2.5">
                  <Check className="mt-1 size-4 shrink-0 text-brass" /> {t}
                </li>
              ))}
            </ul>
          </aside>
        </div>
      </div>
    </section>
  );
}
