import { Check } from "./Icons";

// Aussagen stammen von der bestehenden KKS-Website
const items = [
  { t: "Antwort in 24 Stunden", s: "Garantierte Rückmeldung auf jede Anfrage" },
  { t: "Rund um die Uhr", s: "Ein verlässliches Sicherheitsniveau – Tag und Nacht" },
  { t: "Geschultes Personal", s: "Klare Prozesse und passende Maßnahmen" },
  { t: "Regional & bundesweit", s: "Aus Bergen – bei Bedarf deutschlandweit" },
];

/** Vertrauensleiste direkt nach dem Einstieg: vier Gründe auf einen Blick. */
export default function Trust() {
  return (
    <section className="relative z-10 bg-navy text-ivory">
      <ul className="mx-auto grid max-w-[1600px] grid-cols-2 px-5 sm:px-8 lg:grid-cols-4 lg:px-12">
        {items.map((it, i) => (
          <li key={it.t} className={`flex gap-3.5 border-white/10 py-7 pr-4 lg:py-9 ${i % 2 ? "pl-4 max-lg:border-l" : ""} ${i > 1 ? "max-lg:border-t" : ""} ${i ? "lg:border-l lg:pl-8" : ""}`} data-reveal style={{ ["--d" as string]: `${i * 80}ms` }}>
            <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-brass text-ink">
              <Check className="size-3.5" />
            </span>
            <span>
              <span className="block font-semibold leading-snug">{it.t}</span>
              <span className="mt-1 block text-[0.88rem] leading-snug text-mist">{it.s}</span>
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}
