import About from "@/components/About";
import Contact from "@/components/Contact";
import Coverage from "@/components/Coverage";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Intro from "@/components/Intro";
import MobileBar from "@/components/MobileBar";
import MotionProvider from "@/components/MotionProvider";
import Pillars from "@/components/Pillars";
import Portfolio from "@/components/Portfolio";
import Process from "@/components/Process";
import Trust from "@/components/Trust";

export default function Page() {
  return (
    <>
      <MotionProvider />
      <Intro />
      <Header />
      <main>
        <Hero />
        <Trust />
        <Pillars />
        <Portfolio />
        <Process />
        <Coverage />
        <About />
        <Contact />
      </main>
      <Footer />
      <MobileBar />
    </>
  );
}
