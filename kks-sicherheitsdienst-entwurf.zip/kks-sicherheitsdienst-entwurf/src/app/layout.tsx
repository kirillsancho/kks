import type { Metadata, Viewport } from "next";
import "@fontsource-variable/archivo/wdth.css";
import "@fontsource-variable/newsreader/opsz.css";
import "@fontsource-variable/newsreader/opsz-italic.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "KKS Sicherheitsdienst – Sicherheit mit Zukunft | Bergen & bundesweit",
  description:
    "KKS Sicherheitsdienst e.K. aus Bergen (Niedersachsen): Objektschutz, mobile Sicherheitsdienste und Spezialschutz für Einrichtungen – regional verwurzelt, bei Bedarf bundesweit im Einsatz.",
};

export const viewport: Viewport = {
  themeColor: "#121110",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
