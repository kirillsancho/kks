// Alle Inhalte stammen von kks-sicherheitsdienst.de (Startseite + Impressum, Stand 14.11.2026).
// Keine erfundenen Zahlen, Referenzen, Siegel oder Bewertungen.

export const company = {
  name: "KKS Sicherheitsdienst e.K.",
  short: "KKS Sicherheitsdienst",
  claim: "Sicherheit mit Zukunft",
  owner: "Kemal Kizilyel",
  street: "An der Bahn 2",
  city: "29303 Bergen",
  region: "Niedersachsen",
  phone: { label: "05051 7000042", href: "tel:+4950517000042" },
  emergency: { label: "0176 20774898", href: "tel:+4917620774898" },
  email: { label: "Kontakt@KKS-Sicherheitsdienst.de", href: "mailto:Kontakt@KKS-Sicherheitsdienst.de" },
  maps: "https://www.google.com/maps/search/?api=1&query=An+der+Bahn+2+29303+Bergen",
  register: "Amtsgericht Lüneburg · HRA 204539",
  authority: "IHK Lüneburg-Wolfsburg",
  responseTime: "Antwort innerhalb von 24 Stunden",
};

export type CategoryId =
  | "alle"
  | "unternehmen"
  | "einrichtungen"
  | "eingang"
  | "handel"
  | "privat"
  | "notfall"
  | "personen";

export const categories: { id: CategoryId; label: string }[] = [
  { id: "alle", label: "Alle Leistungen" },
  { id: "unternehmen", label: "Unternehmen & Objekte" },
  { id: "einrichtungen", label: "Öffentliche Einrichtungen" },
  { id: "eingang", label: "Eingang & Empfang" },
  { id: "handel", label: "Einzelhandel" },
  { id: "privat", label: "Privatobjekte" },
  { id: "notfall", label: "Notfall & Brand" },
  { id: "personen", label: "Personen & Mobilität" },
];

export type IconName =
  | "building"
  | "car"
  | "shield"
  | "door"
  | "home"
  | "eye"
  | "factory"
  | "badge"
  | "flame"
  | "siren"
  | "route";

export type Service = {
  id: string;
  title: string;
  short: string;
  text: string;
  icon: IconName;
  cats: CategoryId[];
  core?: boolean;
};

export const services: Service[] = [
  {
    id: "objektschutz",
    title: "Bewachung von Objekten und Anlagen",
    short: "Objektschutz",
    text: "Schutz von Gebäuden, Werken und sensiblen Bereichen. Mit geschultem Personal und lückenloser Überwachung.",
    icon: "building",
    cats: ["unternehmen", "einrichtungen"],
    core: true,
  },
  {
    id: "mobil",
    title: "Mobile Sicherheitsdienste",
    short: "Revier & Streife",
    text: "Revierfahrten, Streifendienste und flexible Kontrollgänge zur Abschreckung und schnellen Intervention bei Auffälligkeiten.",
    icon: "route",
    cats: ["unternehmen", "privat"],
    core: true,
  },
  {
    id: "spezialschutz",
    title: "Spezialschutz für Einrichtungen",
    short: "Spezialschutz",
    text: "Erfahrung im sensiblen Schutz von Flüchtlingsunterkünften, öffentlichen Gebäuden und stark frequentierten Anlagen.",
    icon: "shield",
    cats: ["einrichtungen"],
    core: true,
  },
  {
    id: "doorman",
    title: "Doorman-Services für Eingangsbereiche",
    short: "Doorman",
    text: "Unsere Doormen sorgen für eine sichere und kontrollierte Zutrittssituation, repräsentieren Ihr Unternehmen nach außen und greifen bei Bedarf deeskalierend ein.",
    icon: "door",
    cats: ["eingang", "unternehmen"],
  },
  {
    id: "zutritt",
    title: "Zutrittskontrollen & Empfangsdienste",
    short: "Zutritt & Empfang",
    text: "Wir kombinieren Freundlichkeit mit konsequenter Sicherheitskontrolle, um Besucher zu empfangen und unbefugten Zugang zuverlässig zu verhindern.",
    icon: "badge",
    cats: ["eingang", "unternehmen", "einrichtungen"],
  },
  {
    id: "firmen",
    title: "Firmenüberwachung",
    short: "Firmenüberwachung",
    text: "Schutz Ihrer Unternehmensflächen, Produktionsanlagen und Büroräume – mit präventiven Maßnahmen und schneller Reaktionsfähigkeit im Ernstfall.",
    icon: "factory",
    cats: ["unternehmen"],
  },
  {
    id: "handel",
    title: "Kaufhausdetektiv & Einzelhandelssicherheit",
    short: "Einzelhandel",
    text: "Diskrete Beobachtung und schnelle Intervention im Verkaufsraum, um Ladendiebstähle zu verhindern und für ein sicheres Einkaufserlebnis zu sorgen.",
    icon: "eye",
    cats: ["handel"],
  },
  {
    id: "privat",
    title: "Privatgebäude-Bewachung",
    short: "Privatobjekte",
    text: "Ob dauerhaft oder während Ihrer Abwesenheit – wir schützen Ihr Wohnhaus oder Ferienobjekt zuverlässig vor Einbruch, Vandalismus und unbefugtem Zutritt.",
    icon: "home",
    cats: ["privat"],
  },
  {
    id: "brand",
    title: "Brandschutz & Brandwachen",
    short: "Brandwache",
    text: "Vorbeugende Brandwachen, Brandmeldekontrollen und schnelle Reaktion im Gefahrenfall – durch speziell geschultes Sicherheitspersonal.",
    icon: "flame",
    cats: ["notfall", "unternehmen"],
  },
  {
    id: "notfall",
    title: "Notfallmanagement",
    short: "Notfallmanagement",
    text: "Koordinierte Maßnahmen im Ernstfall – von der Evakuierung bis zur ersten Schadensbegrenzung – für einen sicheren und organisierten Ablauf.",
    icon: "siren",
    cats: ["notfall", "unternehmen", "einrichtungen"],
  },
  {
    id: "chauffeur",
    title: "Chauffeur- & Begleitdienste",
    short: "Chauffeur & Begleitung",
    text: "Diskrete, sichere und komfortable Fahr- und Begleitservices für Personen, die besonderen Schutz und zuverlässige Mobilität benötigen.",
    icon: "car",
    cats: ["personen"],
  },
];

export const pillars = [
  {
    no: "01",
    kicker: "Objekte & Anlagen",
    title: "Bewachung von Objekten und Anlagen",
    text: "Schutz von Gebäuden, Werken und sensiblen Bereichen. Mit geschultem Personal und lückenloser Überwachung.",
    img: "/img/objektschutz.webp",
    imgSm: "/img/objektschutz-800.webp",
    tags: ["Gebäude", "Werke", "Sensible Bereiche"],
  },
  {
    no: "02",
    kicker: "Mobil im Einsatz",
    title: "Mobile Sicherheitsdienste",
    text: "Revierfahrten, Streifendienste und flexible Kontrollgänge zur Abschreckung und schnellen Intervention bei Auffälligkeiten.",
    img: "/img/revierfahrt.webp",
    imgSm: "/img/revierfahrt-800.webp",
    tags: ["Revierfahrten", "Streifendienst", "Kontrollgänge"],
  },
  {
    no: "03",
    kicker: "Sensible Einrichtungen",
    title: "Spezialschutz für Einrichtungen",
    text: "Erfahrung im sensiblen Schutz von Flüchtlingsunterkünften, öffentlichen Gebäuden und stark frequentierten Anlagen.",
    img: "/img/spezialschutz.webp",
    imgSm: "/img/spezialschutz-800.webp",
    tags: ["Unterkünfte", "Öffentliche Gebäude", "Hohe Frequenz"],
  },
];

export const steps = [
  {
    word: "Planen",
    text: "Jedes Einsatzgebiet wird individuell geplant und exakt auf Ihre Anforderungen abgestimmt.",
  },
  {
    word: "Bewachen",
    text: "Professionell durchgeführt – mit klaren Prozessen, geschultem Personal und passenden Maßnahmen.",
  },
  {
    word: "Reagieren",
    text: "Schnelle Intervention bei Auffälligkeiten und koordinierte Maßnahmen im Ernstfall.",
  },
];

export const values = [
  { title: "Individuelle Sicherheitslösungen", text: "Konzepte, die zu Ihrem Objekt, Ihrem Betrieb und Ihrem Risiko passen – nicht von der Stange." },
  { title: "Direkte Kommunikation", text: "Klare Absprachen und kurze Wege – direkt, persönlich und ohne Umwege." },
  { title: "Kompromisslose Zuverlässigkeit", text: "Risiken minimieren, Sicherheit maximieren – mit Konzepten, die funktionieren." },
  { title: "Rund um die Uhr", text: "Ein verlässliches Sicherheitsniveau – genau dort, wo Sie Schutz benötigen." },
];

export const nav = [
  { href: "#leistungen", label: "Leistungen" },
  { href: "#vorgehen", label: "Vorgehen" },
  { href: "#einsatzgebiet", label: "Einsatzgebiet" },
  { href: "#ueber-kks", label: "Über KKS" },
  { href: "#kontakt", label: "Kontakt" },
];
