"use client";

import { useEffect, useRef, useState, type RefObject } from "react";

export function prefersReducedMotion() {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  return reduced;
}

export const clamp = (v: number, min = 0, max = 1) => Math.min(max, Math.max(min, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/**
 * Liefert den Scroll-Fortschritt (0–1) eines Elements an einen Callback –
 * ohne React-Re-Renders, damit es auch auf Mobilgeräten flüssig bleibt.
 * mode "through": 0 wenn Oberkante unten im Viewport, 1 wenn Unterkante oben.
 * mode "sticky": 0 wenn Oberkante oben, 1 wenn Unterkante unten (für gepinnte Sections).
 */
export function useScrollProgress(
  ref: RefObject<HTMLElement | null>,
  cb: (p: number) => void,
  mode: "through" | "sticky" | "enter" = "through",
) {
  const cbRef = useRef(cb);
  cbRef.current = cb;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    let visible = true;

    const measure = () => {
      raf = 0;
      const r = el.getBoundingClientRect();
      const vh = window.innerHeight;
      let p = 0;
      if (mode === "through") p = (vh - r.top) / (vh + r.height);
      else if (mode === "sticky") p = -r.top / Math.max(1, r.height - vh);
      else p = (vh - r.top) / (vh * 0.85);
      cbRef.current(clamp(p));
    };
    const onScroll = () => {
      if (!visible || raf) return;
      raf = requestAnimationFrame(measure);
    };
    const io = new IntersectionObserver(
      ([e]) => {
        visible = e.isIntersecting;
        if (visible) onScroll();
      },
      { rootMargin: "20% 0px 20% 0px" },
    );
    io.observe(el);
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    measure();
    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [ref, mode]);
}

/** Sanftes Scrollen zu einem Anker – nutzt Lenis, falls aktiv. */
export function scrollToHash(hash: string) {
  const target = document.querySelector(hash);
  if (!target) return;
  const lenis = (window as unknown as { __lenis?: { scrollTo: (t: Element, o: object) => void } }).__lenis;
  if (lenis) lenis.scrollTo(target, { offset: window.innerWidth < 768 ? -104 : -72, duration: 1.4 });
  else target.scrollIntoView({ behavior: prefersReducedMotion() ? "auto" : "smooth", block: "start" });
}
