/** Wappenschild aus dem KKS-Logo – als Pfad um (cx, cy) mit Breite s. */
const P: [string, number[]][] = [
  ["M", [-0.5, -0.5]],
  ["C", [-0.26, -0.5, -0.1, -0.545, 0, -0.6]],
  ["C", [0.1, -0.545, 0.26, -0.5, 0.5, -0.5]],
  ["L", [0.5, 0.04]],
  ["C", [0.5, 0.36, 0.26, 0.5, 0, 0.6]],
  ["C", [-0.26, 0.5, -0.5, 0.36, -0.5, 0.04]],
];

export function shieldPath(cx: number, cy: number, s: number, digits = 1) {
  return (
    P.map(([c, n]) => c + n.map((v, i) => (v * s + (i % 2 ? cy : cx)).toFixed(digits)).join(" ")).join("") + "Z"
  );
}

/** Schild für viewBox 0 0 100 120 */
export const SHIELD_100 = shieldPath(50, 60, 100, 2);
