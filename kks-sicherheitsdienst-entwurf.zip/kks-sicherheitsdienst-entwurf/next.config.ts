import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Statischer Export: läuft auf Vercel und als einfache HTML-Vorschau
  output: "export",
  images: { unoptimized: true },
  trailingSlash: true,
};

export default nextConfig;
